rm(list=ls())

#load the packages
library(mvtnorm)
library(tmvtnorm)
library(mnormt)
library(matrixStats)
library(doParallel)
library(doRNG)


#Use the Cauchy distribution
log_q = seq(5,99,by=2)
q = 10^log_q

#real p-values
p_real = pcauchy(q, lower.tail = F)

sigma = diag(rep(1, 2)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu = rep(0, 2) #mean of Y(multivariate normal), which is sqrt(delta)

N_repeat = 100
N_mcmc = 1e4
N_estimate =1e4

p_MCMC_CE = matrix(0, nrow=length(q), ncol=n_repeat) #record p-values from MCMC-CE
time.taken = list()

set.seed(1)
for(k in 1:length(q))
{
  #1. >0
  #define the constraint
  a1 = c(0, 0)
  b1 = c(Inf, Inf)
  D1 = matrix(c(0, 1, 1, -q[k]), 2, 2)
  
  res1 = foreach(i = 1:N_repeat, .packages=c('tmvtnorm','mvtnorm'), .combine=rbind) %dorng%
  {
    time_start = proc.time()
    
    #MCMC sample
    ISsample = rtmvnorm2(n=N_mcmc, mean=mu, sigma=sigma, lower=a1, upper=b1, D=D1, algorithm='gibbs', start.value=c(0,0))
    
    #calculate cross-entropy optimal parameters
    mu_opt = colMeans(ISsample)
    sigma_opt = var(ISsample)
    
    #estimating step
    y = mvtnorm::rmvnorm(n=N_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = mvtnorm::dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    log_lik1 = dmnorm(x=y, mean = mu_opt, varcov=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(c(sum(((y[,1]-q[k]*y[,2] >= 0)&(y[,2] >0))*lik_ratio)/N_estimate, proc.time()-time_start))
  }
  
  #########################################################
  #2. <0
  #define the constraint
  a2 = c(0, 0)
  b2 = c(Inf, Inf)
  D2 = matrix(c(0, -1, -1, q[k]), 2, 2)
  
  res2 = foreach(i = 1:N_repeat, .packages=c('tmvtnorm','mvtnorm'), .combine=rbind) %dorng%
  {
    time_start = proc.time()
    
    #MCMC sample
    ISsample = rtmvnorm2(n=N_mcmc, mean=mu, sigma=sigma, lower=a2, upper=b2, D=D2, algorithm="gibbs", start.value=c(0, 0))
    
    #calculate cross-entropy optimal parameters
    mu_opt = colMeans(ISsample)
    sigma_opt = var(ISsample)
    
    #estimating step
    y = mvtnorm::rmvnorm(n=N_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = mvtnorm::dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(c(sum(((y[,1]-q[k]*y[,2] <= 0)&(y[,2]<0))*lik_ratio)/N_estimate, proc.time()-time_start))
  }
  
  p_MCMC_CE[k,] = res1[,1] + res1[,2]
  
  time.taken[[k]] = res1[,2:6] + res2[,2:6]
  
}

#absolute relative error
p_hat = rowMeans(p_MCMC_CE)
ARE = abs(p_hat-p_real)/p_real

#stardardized MSE and time
SMSE = NA
for(i in 1:dim(p_MCMC_CE)[1])
{
  SMSE[i] = sqrt(sum((p_MCMC_CE[i,]-p_real[i])^2) / length(p_MCMC_CE[i,]))/p_real[i]
  time_ave[i] = mean(time.taken[[i]][,3])
  time_sd[i] = sd(time.taken[[i]][,3])
}

#table S3
tableS3 = cbind(q, p_real, p_hat, ARE, SMSE, time_ave, time_sd)

save.image('/users/yangshi/projects/MCMC_CE/simulation2/simulation2.RData')
