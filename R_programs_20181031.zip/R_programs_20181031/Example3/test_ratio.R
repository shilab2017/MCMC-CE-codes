library(doParallel)
library(doRNG)

test_ratio = function(exp, n1, n2, nmc=1e6, ncore=8)
{
  n=n1+n2
  
  mu = rowMeans(exp)
   
  mu1 = rowMeans(exp[,1:n1])
  
  mu2 = rowMeans(exp[,(1+n1):n])
  
  var1 = rowVars(exp[,1:n1])
  
  var2 = rowVars(exp[,(1+n1):n2])
  
  var_p = ((n1-1)*var1 + (n2-1)*var2) / (n1+n2-2)
  
  sd1 = sqrt(var_p/n1)
    
  sd2 = sqrt(var_p/n2)
  
  q = mu1/mu2

  cl = makeCluster(ncore)
  
  registerDoParallel(cl)
  
  set.seed(1)

  p_res = NA
  
  #for(i in 1:dim(exp)[1])
  #{
  #  sample1 = rtruncnorm(n=nmc, a=0, mean = mu[i], sd = sd1[i])
  #	sample2 = rtruncnorm(n=nmc, a=0, mean = mu[i], sd = sd2[i])
  #	p_res[i] = 2*min((sample1[1:nmc]/sample2[1:nmc] >= q[i])/nmc, (sample1[1:nmc]/sample2[1:nmc] <= q[i])/nmc)
  #}
  
  
  p_value = foreach(i=1:dim(exp)[1], .export='rtruncnorm', .combine=c) %dorng%
  {
    sample1 = rtruncnorm(n=nmc, a=0, mean = mu[i], sd = sd1[i])
  	sample2 = rtruncnorm(n=nmc, a=0, mean = mu[i], sd = sd2[i])
  	return(2*min(sum(sample1[1:nmc]/sample2[1:nmc] >= q[i])/nmc, sum(sample1[1:nmc]/sample2[1:nmc] <= q[i])/nmc))
  }
  
  stopCluster(cl)
  
  return(cbind(q,p_value))
}

HMC_ratio = function(q, mu, sd, N_mcmc=1e4, N_estimate=1e4, N_repeat=1e2, ncore=8)
{
  p_estimate = matrix(0, nrow=length(q), ncol=N_repeat)
  time.taken = NA
  for(k in 1:length(q))
  {
    start.time = proc.time()
    
    #define the constraint
    a1 = c(0, 0)
    b1 = c(Inf, Inf)
    D1 = matrix(c(0, 1, 1, -q[k]), 2, 2)
    
    for(i in 1:N_repeat)
    {
      #MCMC sample
      ISsample = rtmvnorm2(n=N_mcmc, mean=c(mu[k],mu[k]), sigma=diag(sd[k],sd[k]), lower=a1, upper=b1, D=D1, algorithm='gibbs', start.value=c(0,0))
      
      #calculate cross-entropy optimal parameters
      mu_opt = colMeans(ISsample)
      sigma_opt = var(ISsample)
      
      #estimating step
      y = mvtnorm::rmvnorm(n=N_estimate, mean=mu_opt, sigma=sigma_opt)
      log_lik0 = mvtnorm::dmvnorm(x=y, mean=c(mu[k],mu[k]), sigma=diag(sd[k],sd[k]), log = T)
      log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
      log_lik1 = dmnorm(x=y, mean = mu_opt, varcov=sigma_opt, log = T)
      lik_ratio = exp(log_lik0 - log_lik1)
      p_estimate[k,i] = sum(((y[,1]-q[k]*y[,2] >= 0)&(y[,2] >0))*lik_ratio)/N_estimate
    }
  }
  
  return(p_estimate*2)
}


