#This script generates the results of the 1st simulation experiment of Shi et al "Accurate and Efficient Calculation of Small P-Values with the Cross-Entropy Method"
#This experiment uses the MCMC-CE algorithm to calculate p-values of chi^2 distributions
#and compare the performance with Davies's method, Farebrother's method, Imhof's method
#notation: chi^2(nu,delta), nu is degrees of freedom, delta is the non-central parameter
#Since we used central chi-squared distributions, therefore delta is all 0's, but needs to be given

rm(list=ls())

#load all packages used
library(tmg)
library(CompQuadForm)
library(mvtnorm)
library(doParallel)
library(doRNG)
library(matrixStats)

#source the script for the Hamiltonian Monte Carlo sampler
source('/users/yangshi/projects/MCMC_CE/simulation1/HMC_sampler.R')

#two functions to calculate absolute relative error and standardized mean squared error
cal_ARE = function(p_estimate, p) #absolute relative error
{
  return(abs(mean(p_estimate)-p)/p)
}

cal_SMSE = function(p_estimate, p) #the standardized mean squared error (SMSE) - MSE is too small to use
{
  return( sqrt(sum((p_estimate-p)^2) / length(p_estimate))/p )
}

########################################################################################################
#Setting 1: chi^2(nu=5,delta=0)
nu1=5
delta1=0

lambda1 = rep(1, times=nu1) #the weights in the linear combination of chi_squares 
D1 = diag(lambda1)

q1 =  seq(35,475,by=10) #critical values
p_real1 = pchisq(q1, df=nu1, lower.tail=F) #true tail probability

p_d1 = p_f1 = p_i1 = NA
ARE_d1 = ARE_f1 = ARE_i1 = NA
time_d1 = time_f1 = time_i1 = matrix(0, nrow=length(q1), ncol=5)

#Below are parameters for HMC-CE:
sigma1 = diag(rep(1, nu1)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu1 = rep(0, nu1) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M1 = solve(sigma1)
r1 = as.vector(M1 %*% mu1)

initial1 = rep(50, nu1) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A1 = D1
B1 = rep(0,nu1)
C1 = (-q1)

p_HMC1 = matrix(0, nrow=length(q1), ncol=100)
p_HMC_hat1 = ARE_HMC1 = SMSE_HMC1 = NA
time.taken1 = list()

for(k in 1:length(q1))
{
  #Davies method
  start_d = proc.time()
  p_d1[k] = davies(q=q1[k], lambda=1, h=nu1, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d1[k,] = proc.time() - start_d
  ARE_d1[k] = abs(p_d1[k]-p_real1[k])/p_real1[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f1[k] = farebrother(q=q1[k], lambda=1, h=nu1, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f1[k,] = proc.time() - start_f
  ARE_f1[k] = abs(p_f1[k]-p_real1[k])/p_real1[k]
  
  #Imhof method
  start_i = proc.time()
  p_i1[k] = imhof(q=q1[k], lambda=1, h=nu1)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i1[k,] = proc.time() - start_i
  ARE_i1[k] = abs(p_i1[k]-p_real1[k])/p_real1[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr1 = list(list(A1,B1,C1[k]))
  
  set.seed(1)
  
  res = HMC_sampler(M=M1, r=r1, constr=constr1, q=q1[k], initial=initial1, mu=mu1, sigma=sigma1)
  
  p_HMC1[k,] = res[,1]
  
  time.taken1[[k]] = res[,2:6]
}


########################################################################################################

#Setting 2: chi^2(nu=20,delta=0)
nu2=20
delta2=0

lambda2 = rep(1, times=nu2) #the weights in the linear combination of chi_squares 
D2 = diag(lambda2)

q2 =  seq(65,535,by=10) #critical values
p_real2 = pchisq(q2, df=nu2, lower.tail=F) #true tail probability

p_d2 = p_f2 = p_i2 = NA
ARE_d2 = ARE_f2 = ARE_i2 = NA
time_d2 = time_f2 = time_i2 = matrix(0, nrow=length(q2), ncol=5)

#Below are parameters for HMC-CE:
sigma2 = diag(rep(1, nu2)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu2 = rep(0, nu2) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M2 = solve(sigma2)
r2 = as.vector(M2 %*% mu2)

initial2 = rep(50, nu2) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A2 = D2
B2 = rep(0,nu2)
C2 = (-q2)

p_HMC2 = matrix(0, nrow=length(q2), ncol=100)
p_HMC_hat2 = ARE_HMC2 = SMSE_HMC2 = NA
time.taken2 = list()

for(k in 1:length(q2))
{
  #Davies method
  start_d = proc.time()
  p_d2[k] = davies(q=q2[k], lambda=1, h=nu2, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d2[k,] = proc.time() - start_d
  ARE_d2[k] = abs(p_d2[k]-p_real2[k])/p_real2[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f2[k] = farebrother(q=q2[k], lambda=1, h=nu2, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f2[k,] = proc.time() - start_f
  ARE_f2[k] = abs(p_f2[k]-p_real2[k])/p_real2[k]
  
  #Imhof method
  start_i = proc.time()
  p_i2[k] = imhof(q=q2[k], lambda=1, h=nu2)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i2[k,] = proc.time() - start_i
  ARE_i2[k] = abs(p_i2[k]-p_real2[k])/p_real2[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr2 = list(list(A2,B2,C2[k]))
  
  set.seed(1)
  
  res = HMC_sampler(M=M2, r=r2, constr=constr2, q=q2[k], initial=initial2, mu=mu2, sigma=sigma2)
  
  p_HMC2[k,] = res[,1]
  
  time.taken2[[k]] = res[,2:6]
}

########################################################################################################
#Setting 3: chi^2(nu=50,delta=0)
nu3=50
delta3=0

lambda3 = rep(1, times=nu3) #the weights in the linear combination of chi_squares 
D3 = diag(lambda3)

q3 =  seq(110,620,by=10) #critical values
p_real3 = pchisq(q3, df=nu3, lower.tail=F) #true tail probability

p_d3 = p_f3 = p_i3 = NA
ARE_d3 = ARE_f3 = ARE_i3 = NA
time_d3 = time_f3 = time_i3 = matrix(0, nrow=length(q3), ncol=5)

#Below are parameters for HMC-CE:
sigma3 = diag(rep(1, nu3)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu3 = rep(0, nu3) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M3 = solve(sigma3)
r3 = as.vector(M3 %*% mu3)

initial3 = rep(50, nu3) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A3 = D3
B3 = rep(0,nu3)
C3 = (-q3)

p_HMC3 = matrix(0, nrow=length(q3), ncol=100)
p_HMC_hat3 = ARE_HMC3 = SMSE_HMC3 = NA
time.taken3 = list()

for(k in 1:length(q3))
{
  #Davies method
  start_d = proc.time()
  p_d3[k] = davies(q=q3[k], lambda=1, h=nu3, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d3[k,] = proc.time() - start_d
  ARE_d3[k] = abs(p_d3[k]-p_real3[k])/p_real3[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f3[k] = farebrother(q=q3[k], lambda=1, h=nu3, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f3[k,] = proc.time() - start_f
  ARE_f3[k] = abs(p_f3[k]-p_real3[k])/p_real3[k]
  
  #Imhof method
  start_i = proc.time()
  p_i3[k] = imhof(q=q3[k], lambda=1, h=nu3)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i3[k,] = proc.time() - start_i
  ARE_i3[k] = abs(p_i3[k]-p_real3[k])/p_real3[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr3 = list(list(A3,B3,C3[k]))
  
  set.seed(1)
  
  res = HMC_sampler(M=M3, r=r3, constr=constr3, q=q3[k], initial=initial3, mu=mu3, sigma=sigma3)
  
  p_HMC3[k,] = res[,1]
  
  time.taken3[[k]] = res[,2:6]
}

########################################################################################################
#Setting 4: chi^2(nu=100,delta=0)
nu4=100
delta4=0

lambda4 = rep(1, times=nu4) #the weights in the linear combination of chi_squares 
D4 = diag(lambda4)

q4 =  seq(190,750,by=10) #critical values
p_real4 = pchisq(q4, df=nu4, lower.tail=F) #true tail probability

p_d4 = p_f4 = p_i4 = NA
ARE_d4 = ARE_f4 = ARE_i4 = NA
time_d4 = time_f4 = time_i4 = matrix(0, nrow=length(q4), ncol=5)

#Below are parameters for HMC-CE:
sigma4 = diag(rep(1, nu4)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu4 = rep(0, nu4) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M4 = solve(sigma4)
r4 = as.vector(M4 %*% mu4)

initial4 = rep(50, nu4) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A4 = D4
B4 = rep(0,nu4)
C4 = (-q4)

p_HMC4 = matrix(0, nrow=length(q4), ncol=100)
p_HMC_hat4 = ARE_HMC4 = SMSE_HMC4 = NA
time.taken4 = list()
  
for(k in 1:length(q4))
{
  #Davies method
  start_d = proc.time()
  p_d4[k] = davies(q=q4[k], lambda=1, h=nu4, lim=50000, acc=1e-100)$Qq #we have tried different lim and acc - results do not change
  time_d4[k,] = proc.time() - start_d
  ARE_d4[k] = abs(p_d4[k]-p_real4[k])/p_real4[k]
  
  #Farebrother method
  start_f = proc.time()
  p_f4[k] = farebrother(q=q4[k], lambda=1, h=nu4, eps=1e-150)$Qq #we have tried different eps - results do not change
  time_f4[k,] = proc.time() - start_f
  ARE_f4[k] = abs(p_f4[k]-p_real4[k])/p_real4[k]
  
  #Imhof method
  start_i = proc.time()
  p_i4[k] = imhof(q=q4[k], lambda=1, h=nu4)$Qq #we have tried different epsabs, epsrel and limit values - results do not change
  time_i4[k,] = proc.time() - start_i
  ARE_i4[k] = abs(p_i4[k]-p_real4[k])/p_real4[k]
  
  #MCMC-CE
  #the quadratic constraint of HMC for multivariate gaussian
  constr4 = list(list(A4,B4,C4[k]))
  
  set.seed(1)
  
  res = HMC_sampler(M=M4, r=r4, constr=constr4, q=q4[k], initial=initial4, mu=mu4, sigma=sigma4)
  
  p_HMC4[k,] = res[,1]
  
  time.taken4[[k]] = res[,2:6]
  
}

save.image('/users/yangshi/projects/MCMC_CE/simulation1/simulation.RData')
