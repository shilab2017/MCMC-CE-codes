HMC_sampler = function(M, r, constr, q, initial, mu, sigma, n_HMC=1e4, n_est=1e4, n_burnin=1e3, n_repeat=100, ncore=8)
{
  registerDoParallel(ncore)
  
  res = foreach(i=1:n_repeat, .export='rtmg', .combine=rbind) %dorng%
  {
    time_start = proc.time()
    
    #A. parameters updating step: estimate parameters of the CE optimal proposal density for importance sampling
    #run the HMC sampler
    HMC_sample = rtmg(n=n_HMC, M=M, r=r, initial=initial, q=constr, burn.in=n_burnin)
  
    mu_opt = colMeans(HMC_sample)
    sigma_opt = var(HMC_sample)
    
    #B. estimating step
    y = mvtnorm::rmvnorm(n=n_est, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = mvtnorm::dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(c(sum((rowSums(y^2) >= q)*lik_ratio)/n_est, proc.time()-time_start))
  }
  
  return(res) 
}