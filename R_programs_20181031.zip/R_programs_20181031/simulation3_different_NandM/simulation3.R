rm(list=ls())

#load all packages used
library(tmg)
library(CompQuadForm)
library(mvtnorm)
library(doParallel)
library(doRNG)
library(matrixStats)

setwd('/users/yangshi/projects/MCMC_CE/simulation1/simulation3')

#source the script for the Hamiltonian Monte Carlo sampler
source('HMC_sampler.R')

#function to calculate standardized MSE
cal_SMSE = function(p_estimate, p) #the standardized mean squared error (SMSE) - MSE is too small to use
{
  return( sqrt(sum((p_estimate-p)^2) / length(p_estimate))/p )
}

#Below are global parameters for HMC-CE:
n_repeat = 100
N_HMC = c(1e2, 5e2, 1e3, 1e4, 1e5) #number of random samples drawn from g*, i.e. N in the paper
M_est = c(1e3, 1e4, 1e5) #number of random samples in the estimating step, i.e. M in the paper

#Setting 1: chi^2(nu=5,delta=0)
nu1=5
delta1=0

lambda1 = rep(1, times=nu1) #the weights in the linear combination of chi_squares 
D1 = diag(lambda1)

q1 = c(35, 55, 103, 244, 476) #critical values
p_real1 = pchisq(q1, df=nu1, lower.tail=F) #true tail probability

sigma1 = diag(rep(1, nu1)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu1 = rep(0, nu1) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M1 = solve(sigma1)
r1 = as.vector(M1 %*% mu1)

initial1 = rep(50, nu1) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A1 = D1
B1 = rep(0,nu1)
C1 = (-q1)

p_HMC1 = list()
time.taken1 = list()
SMSE1 = list()

set.seed(1)

for(iter in 1:length(q1))
{
  #the quadratic constraint of HMC for multivariate gaussian
  constr1 = list(list(A1,B1,C1[iter]))

  p_HMC1[[iter]] = matrix(0, nrow=length(N_HMC)*length(M_est), ncol=n_repeat)
  SMSE1[[iter]] = NA

for(i in 1:length(N_HMC))
{
  for(j in 1:length(M_est))
  {
    k = length(M_est)*(i-1) + j
    
    res = HMC_sampler(M=M1, r=r1, constr=constr1, q=q1[iter], initial=initial1, mu=mu1, sigma=sigma1, n_HMC = N_HMC[i], n_est = M_est[j], n_repeat = n_repeat)
    
    p_HMC1[[iter]][k,] = res[,1]
    
    time.taken1[[(iter-1)*length(M_est)*length(N_HMC)+length(M_est)*(i-1)+j]] = res[,2:6]

    SMSE1[[iter]][k] = cal_SMSE(p_HMC1[[iter]][k,],p_real1[iter])
  }
}
}

#Setting 2: chi^2(nu=20,delta=0)
nu2=20
delta2=0

lambda2 = rep(1, times=nu2) #the weights in the linear combination of chi_squares 
D2 = diag(lambda2)

q2 = c(65, 88, 143, 294, 535)

p_real2 = pchisq(q2, df=nu2, lower.tail=F) #true tail probability

sigma2 = diag(rep(1, nu2)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu2 = rep(0, nu2) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M2 = solve(sigma2)
r2 = as.vector(M2 %*% mu2)

initial2 = rep(50, nu2) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A2 = D2
B2 = rep(0,nu2)
C2 = (-q2)

p_HMC2 = list()
time.taken2 = list()
SMSE2 = list()

for(iter in 1:length(q2))
{
  #the quadratic constraint of HMC for multivariate gaussian
  constr2 = list(list(A2,B2,C2[iter]))
  
  p_HMC2[[iter]] = matrix(0, nrow=length(N_HMC)*length(M_est), ncol=n_repeat)
  SMSE2[[iter]] = NA
  
  for(i in 1:length(N_HMC))
  {
    for(j in 1:length(M_est))
    {
      k = length(M_est)*(i-1) + j
      
      res = HMC_sampler(M=M2, r=r2, constr=constr2, q=q2[iter], initial=initial2, mu=mu2, sigma=sigma2, n_HMC = N_HMC[i], n_est = M_est[j], n_repeat = n_repeat)
      
      p_HMC2[[iter]][k,] = res[,1]
      
      time.taken2[[(iter-1)*length(M_est)*length(N_HMC)+length(M_est)*(i-1)+j]] = res[,2:6]
      
      SMSE2[[iter]][k] = cal_SMSE(p_HMC2[[iter]][k,],p_real2[iter])
    }
  }
}

#Setting 3: chi^2(nu=50,delta=0)
nu3=50
delta3=0

lambda3 = rep(1, times=nu3) #the weights in the linear combination of chi_squares 
D3 = diag(lambda3)

q3 = c(112, 141, 205, 371, 627)
p_real3 = pchisq(q3, df=nu3, lower.tail=F) #true tail probability

sigma3 = diag(rep(1, nu3)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu3 = rep(0, nu3) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M3 = solve(sigma3)
r3 = as.vector(M3 %*% mu3)

initial3 = rep(50, nu3) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A3 = D3
B3 = rep(0,nu3)
C3 = (-q3)

p_HMC3 = list()
time.taken3 = list()
SMSE3 = list()

for(iter in 1:length(q3))
{
  #the quadratic constraint of HMC for multivariate gaussian
  constr3 = list(list(A3,B3,C3[iter]))
  
  p_HMC3[[iter]] = matrix(0, nrow=length(N_HMC)*length(M_est), ncol=n_repeat)
  SMSE3[[iter]] = NA
  
  for(i in 1:length(N_HMC))
  {
    for(j in 1:length(M_est))
    {
      k = length(M_est)*(i-1) + j
      
      res = HMC_sampler(M=M3, r=r3, constr=constr3, q=q3[iter], initial=initial3, mu=mu3, sigma=sigma3, n_HMC = N_HMC[i], n_est = M_est[j], n_repeat = n_repeat)
      
      p_HMC3[[iter]][k,] = res[,1]
      
      time.taken3[[(iter-1)*length(M_est)*length(N_HMC)+length(M_est)*(i-1)+j]] = res[,2:6]
      
      SMSE3[[iter]][k] = cal_SMSE(p_HMC3[[iter]][k,],p_real3[iter])
    }
  }
}

#add one more case: N = 5e5 for p-value=10^-100
N_HMC3_add = 5e5
p_HMC3_add = matrix(0, nrow=length(M_est), ncol=n_repeat)
time.taken3_add = list()
SMSE3_add = NA
  
for(i in 1:length(M_est))
{
  res = HMC_sampler(M=M3, r=r3, constr=list(list(A3,B3,C3[length(q3)])), q=q3[length(q3)], initial=initial3, mu=mu3, sigma=sigma3, n_HMC = N_HMC3_add, n_est = M_est[i], n_repeat = n_repeat)
  
  p_HMC3_add[i,] = res[,1]
  
  time.taken3_add[[i]] = res[,2:6]
  
  SMSE3_add[i] = cal_SMSE(p_HMC3_add[i,],p_real3[length(q3)])
}

#Setting 4: chi^2(nu=100,delta=0)
nu4 = 100
delta4 = 0

lambda4 = rep(1, times=nu4) #the weights in the linear combination of chi_squares 
D4 = diag(lambda4)

q4 = c(181, 217, 292, 478, 752)
p_real4 = pchisq(q4, df=nu4, lower.tail=F) #true tail probability

sigma4 = diag(rep(1, nu4)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
mu4 = rep(0, nu4) #mean of Y(multivariate normal), which is sqrt(delta)

#alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
M4 = solve(sigma4)
r4 = as.vector(M4 %*% mu4)

initial4 = rep(50, nu4) #start value for the HMC sampler

#quadratic constrains: (X^T)AX + (B^T)X + C >= 0
A4 = D4
B4 = rep(0,nu4)
C4 = (-q4)

p_HMC4 = list()
time.taken4 = list()
SMSE4 = list()

for(iter in 1:length(q4))
{
  #the quadratic constraint of HMC for multivariate gaussian
  constr4 = list(list(A4,B4,C4[iter]))
  
  p_HMC4[[iter]] = matrix(0, nrow=length(N_HMC)*length(M_est), ncol=n_repeat)
  SMSE4[[iter]] = NA
  
  for(i in 1:length(N_HMC))
  {
    for(j in 1:length(M_est))
    {
      k = length(M_est)*(i-1) + j
      
      res = HMC_sampler(M=M4, r=r4, constr=constr4, q=q4[iter], initial=initial4, mu=mu4, sigma=sigma4, n_HMC = N_HMC[i], n_est = M_est[j], n_repeat = n_repeat)
      
      p_HMC4[[iter]][k,] = res[,1]
      
      time.taken4[[(iter-1)*length(M_est)*length(N_HMC)+length(M_est)*(i-1)+j]] = res[,2:6]
      
      SMSE4[[iter]][k] = cal_SMSE(p_HMC4[[iter]][k,],p_real4[iter])
    }
  }
}

#add one more case: N = 5e5 for p-value=10^-100
N_HMC4_add = 5e5
p_HMC4_add = matrix(0, nrow=length(M_est)*length(q4), ncol=n_repeat)
time.taken4_add = list()
SMSE4_add = NA

for(i in 1:length(q4))
{
for(j in 1:length(M_est))
{
  k = length(M_est)*(i-1) + j
  
  res = HMC_sampler(M=M4, r=r4, constr=list(list(A4,B4,C4[i])), q=q4[i], initial=initial4, mu=mu4, sigma=sigma4, n_HMC = N_HMC4_add, n_est = M_est[j], n_repeat = n_repeat)
  
  p_HMC4_add[k,] = res[,1]
  
  time.taken4_add[[k]] = res[,2:6]
  
  SMSE4_add[k] = cal_SMSE(p_HMC4_add[k,], p_real4[i])
}
}

elapse_time1 = NA
elapse_sd1 = NA
for(i in 1:length(time.taken1))
{
  temp = time.taken1[[i]][,3]
  elapse_time1[i] = mean(temp)
  elapse_sd1[i] = sd(temp)
}

elapse_time2 = NA
elapse_sd2 = NA
for(i in 1:length(time.taken2))
{
  temp = time.taken2[[i]][,3]
  elapse_time2[i] = mean(temp)
  elapse_sd2[i] = sd(temp)
}

elapse_time3 = NA
elapse_sd3 = NA
for(i in 1:length(time.taken3))
{
  temp = time.taken3[[i]][,3]
  elapse_time3[i] = mean(temp)
  elapse_sd3[i] = sd(temp)
}

elapse_time3_add = NA
elapse_sd3_add = NA
for(i in 1:length(time.taken3_add))
{
  temp = time.taken3_add[[i]][,3]
  elapse_time3_add[i] = mean(temp)
  elapse_sd3_add[i] = sd(temp)
}

elapse_time4 = NA
elapse_sd4 = NA
for(i in 1:length(time.taken4))
{
  temp = time.taken4[[i]][,3]
  elapse_time4[i] = mean(temp)
  elapse_sd4[i] = sd(temp)
}

elapse_time4_add = NA
elapse_sd4_add = NA
for(i in 1:length(time.taken4_add))
{
  temp = time.taken4_add[[i]][,3]
  elapse_time4_add[i] = mean(temp)
  elapse_sd4_add[i] = sd(temp)
}

save.image('simulation3_differentNandM.RData')