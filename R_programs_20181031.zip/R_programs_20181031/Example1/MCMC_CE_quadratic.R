MCMC_CE_quadratic = function(D, q, initial, mu, M, r, constr1, n_MCMC=1e4, n_estimate=1e4, n_burnin=1e3, n_repeat=100, ncore=8)
{
  registerDoParallel(ncore)
  res = foreach(i=1:n_repeat, .export=c('rtmg','rmvnorm','dmvnorm'),.combine=c) %dorng% 
  {  
    time_start = proc.time()
    
    HMC_sample = rtmg(n=n_MCMC, M=M, r=r, initial=initial, q=list(constr1), burn.in=n_burnin)
    
    #estimate parameters of the optimal proposal density for importance sampling
    mu_opt = colMeans(HMC_sample)
    sigma_opt = var(HMC_sample)
    
    #estimating step
    y = rmvnorm(n=n_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(c(sum((rowSums( (y * y) %*% D) >= q)*lik_ratio)/n_estimate, proc.time()-time_start))
  }
  return(res)
}