rm(list=ls())

#load the packages used
library(golubEsets)
library(vsn)
library(hu6800.db)
library(samr)
library(matrixStats)
library(truncnorm)
library(mvtnorm)
library(tmvtnorm)
library(mnormt)

full_list = as.list(hu6800SYMBOL)

gene_probe = as.data.frame(unlist(full_list))

#load the data
data(Golub_Train)
exprs(Golub_Train) = exprs(vsn2(Golub_Train))
exp = exprs(Golub_Train)
phenoData(Golub_Train)$ALL.AML #27 ALL; 11 AML

probename = rownames(exp) #extract the probe name

genename = as.character(gene_probe[match(probename,rownames(gene_probe)),]) #extract the gene name

#load the script with functions for crude MC methods and MCMC-CE algorithms for ratio statistic
source('/users/yangshi/projects/MCMC_CE/example3/test_ratio.R')

#first try n_mc = 1e5
#res = test_ratio(exp=exp, n1=27, n2=11, nmc=1e5)
#res[(res[,2]<1e-5),]
#sum(res[,2]<1e-5) #272 

#######################################################################################################
#run the crude MC methods and select those probes with p<1e-5
#n_mc = 1e6, select those < 1e-5
res1 = test_ratio(exp=exp, n1=27, n2=11)
sum(res1[,2]<1e-5) #293 probes
sum(res1[,2]<1e-6) #187 probes
mu1_all = rowMeans(exp[,1:n1])
mu2_all = rowMeans(exp[,(1+n1):n])
mean_all = cbind(mu1_all, mu2_all)
ratio_all = cbind(mu1_all/mu2_all, mu2_all/mu1_all)

exp_small = exp[which(res1[,2]<1e-5),]
#######################################################################################################
#exp_small = exp_small[!(rownames(exp_small) %in% not_work),]
#not_work = rownames(exp_small)[c(54,61,67,129,131)]

#######################################################################################################
#run the MCMC-CE algorithm to accurately calculate small p-values for those probes with p<1e-5

n1=27
n2=11
n=n1+n2
mu = rowMeans(exp_small)

mu1 = rowMeans(exp_small[,1:n1])

mu2 = rowMeans(exp_small[,(1+n1):n])

var1 = rowVars(exp_small[,1:n1])/n1

var2 = rowVars(exp_small[,(1+n1):n])/n2

ratio_com = cbind(mu1/mu2, mu2/mu1)

index = (ratio_com[,1]>ratio_com[,2])

q = rowMaxs(ratio_com)

N_mcmc=1e4
N_estimate=1e4
N_repeat=100

p_estimate = matrix(0, nrow=length(q), ncol=N_repeat)
time.taken = NA
n_failure = NA #count the failure of MCMC sampling
set.seed(1)
for(k in 1:length(q))
{
  #if(k %in% c(54,61,67,129,131))
  #{
  #  next;
  #}
  
  start.time = proc.time()
  
  avg = c(mu[k],mu[k])
  
  if(index[k]) #mu1 > mu2
  {
    sigma = diag(c(var1[k],var2[k]))
  }else
  {
    sigma = diag(c(var1[k],var2[k]))
  }
  
  #define the constraint
  a1 = c(0, 0)
  b1 = c(Inf, Inf)
  D1 = matrix(c(0, 1, 1, -q[k]), 2, 2)
  
  n_failure[k] = 0 #count the failure of MCMC sample
  for(i in 1:N_repeat)
  {
    #MCMC sample - gibbs sampling
    ISsample = rtmvnorm2(n=N_mcmc, mean=avg, sigma=sigma, lower=a1, upper=b1, D=D1, start.value=c(0,1), algorithm = 'gibbs', burn.in.samples=N_mcmc/10)
    
    ISsample = ISsample[!rowSums(!is.finite(ISsample)),]
    
    if(dim(ISsample)[1]==0) #if MCMC sampling often fails, skip the gene
    {
      n_failure[k] = n_failure[k]+1
      next;
    }
    
    #calculate cross-entropy optimal parameters
    mu_opt = colMeans(ISsample,na.rm=T)
    sigma_opt = var(ISsample)
    
    #estimating step
    y = mvtnorm::rmvnorm(n=N_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = mvtnorm::dmvnorm(x=y, mean=avg, sigma=sigma, log = T)
    log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    log_lik1 = dmnorm(x=y, mean = mu_opt, varcov=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    p_estimate[k,i] = sum(((y[,1]-q[k]*y[,2] >= 0)&(y[,2] >0))*lik_ratio)/N_estimate
  }
  
  time.taken[k] = (proc.time() - start.time)[3]
}
#######################################################################################################

#######################################################################################################
#run the samr packages

label=c(rep(1,n1),rep(2,n2))

samfit = SAM(x=exp, y=label, resp.type="Two class unpaired", geneid=probename, genenames=genename,fdr.output=1+1e-6)

up_genes_sam = samfit$siggenes.table$genes.up
down_genes_sam = samfit$siggenes.table$genes.lo

#summarize data
res_crude = data.frame(probename, genename, mean_all, ratio_all, res1)
up_gene_crude = res_crude[res_crude[,6]>1,]
down_gene_crude = res_crude[res_crude[,6]<1,]

#check the results with SAM
length(intersect(up_gene_crude$probename,up_genes_sam[,2]))
length(intersect(down_gene_crude$probename,down_genes_sam[,2]))
setdiff(down_genes_sam[,2],down_gene_crude$probename)

#there is one gene: 'HG2887-HT3031_at' is mis-categorized by SAM as down-regulated, should be up-regulated
res_crude[res_crude$probename=='HG2887-HT3031_at',]
down_genes_sam[down_genes_sam[,2]=='HG2887-HT3031_at',]
up_genes_sam[up_genes_sam[,2]=='HG2887-HT3031_at',]

#combine the resutls
up_genes_sam1 = up_genes_sam[,c(2,7)]
colnames(up_genes_sam1) = c('probename','SAM_FDR(%)')
down_genes_sam1 = down_genes_sam[,c(2,7)]
colnames(down_genes_sam1) = c('probename','SAM_FDR(%)')

up_crude_sam = merge(up_gene_crude, up_genes_sam1, by='probename', all.x=T)
#add the result of 'HG2887-HT3031_at', which is mis-classified by SAM
up_crude_sam[up_crude_sam$probename=='HG2887-HT3031_at','SAM_FDR(%)'] = down_genes_sam[down_genes_sam[,2]=='HG2887-HT3031_at',7]
up_crude_sam[,'SAM_FDR(%)'] = as.numeric(as.character(up_crude_sam[,'SAM_FDR(%)']))
up_crude_sam[is.na(up_crude_sam$SAM_FDR),'SAM_FDR(%)'] = 100

down_crude_sam = merge(down_gene_crude, down_genes_sam1, by='probename', all.x=T)
down_crude_sam[,'SAM_FDR(%)'] = as.numeric(as.character(down_crude_sam[,'SAM_FDR(%)']))
down_crude_sam[is.na(down_crude_sam$SAM_FDR),'SAM_FDR(%)'] = 100

p_MCMC_CE = NA
SD_MCMC_CE = NA
#summarize the results of MCMC-CE
for(i in 1:dim(p_estimate)[1])
{
  if(n_failure[i]<=50) #if Gibbs sampling fails for 50%, have to remove
  {
    temp = p_estimate[i,]
    temp = temp[temp!=0]
    p_MCMC_CE[i] = mean(temp)
    SD_MCMC_CE[i] = sd(temp)
  }
}

MCMC_CE_res = data.frame(probename = row.names(exp_small), p_MCMC_CE, SD_MCMC_CE)
MCMC_CE_res[is.na(MCMC_CE_res$p_MCMC_CE),] #M77142_at, X82240_rna1_at, M55150_at fail 

MCMC_CE_res1 = MCMC_CE_res[!is.na(MCMC_CE_res$p_MCMC_CE),] #remove thoese 3 failed probes

#merge
up_all = merge(up_crude_sam, MCMC_CE_res1, by='probename', all.x=T)
down_all = merge(down_crude_sam, MCMC_CE_res1, by='probename', all.x=T)

up_all = up_all[order(up_all$p_MCMC_CE, up_all$p_value),]
down_all = down_all[order(down_all$p_MCMC_CE, down_all$p_value),]

#rename column names for output
colnames(up_all)[c(3,4,5,6,8)] = c('mu1','mu2','mu1/mu2','mu2/mu1','p_crude_MC')
colnames(down_all)[c(3,4,5,6,8)] = c('mu1','mu2','mu1/mu2','mu2/mu1','p_crude_MC')

up_all$genename = as.character(up_all$genename)
down_all$genename = as.character(down_all$genename)
up_all[is.na(up_all)] = '-'
down_all[is.na(down_all)] = '-'

write.table(up_all, file='/users/yangshi/projects/MCMC_CE/example3/up_ratio_AMLALL.txt', row.names=F,
            quote=F, sep='\t')
write.table(down_all, file='/users/yangshi/projects/MCMC_CE/example3/down_ratio_AMLALL.txt', row.names=F,
            quote=F, sep='\t')
save.image('/users/yangshi/projects/MCMC_CE/example3/AML_ALL.RData')

#######################################################################################################
#some comparisons with SAM and summary statistics - as reported in our paper
#sam.fdr.up = up_all[up_all$p_crude_MC<1e-5,9]
#sam.fdr.down = down_all[down_all$p_crude_MC<1e-5,9]

#summary(sam.fdr.up) #max is 2.371%
#summary(sam.fdr.down) #max is 4.587%

#sum(sam.fdr.up==0)+sum(sam.fdr.down==0)
