rm(list=ls())

library(matrixStats)
library(truncnorm)
library(tmvtnorm)
library(mnormt)
library(combinat)
library(gtools)
library(samr)
library(reshape)

setwd('/users/yangshi/projects/MCMC_CE/example3/')
source('/users/yangshi/projects/MCMC_CE/example3/test_ratio.R')
load("ACC_FOC.RData")

set.seed(1)

#group the indices of the samples
FOC = c(1,2,3,6,9,11,12,14)
NOT = c(4,5,7,8,10,13)
exp = cbind(mat[,FOC], mat[,NOT])

#1.crude Monte Carlo
res1 = test_ratio(exp=exp, n1=8, n2=6, nmc=1e5) #this function is in the "test_ratio.R script"
res1_BH = p.adjust(res1[,2], method = "BH")

#2.HMC-CE
small_index = which(res1[,2]<1e-4) #index of genes with p-value<1e-4
exp_small = exp[small_index,]
n1=8
n2=6
n=n1+n2
mu = rowMeans(exp_small)
mu1 = rowMeans(exp_small[,1:n1])
mu2 = rowMeans(exp_small[,(1+n1):n])
var1_s = rowVars(exp_small[,1:n1])
var2_s = rowVars(exp_small[,(1+n1):n2])
var_p = ((n1-1)*var1_s + (n2-1)*var2_s) / (n1+n2-2)
var1 = var_p/n1
var2 = var_p/n2

ratio_com = cbind(mu1/mu2, mu2/mu1)

index = (ratio_com[,1]>ratio_com[,2])

q = rowMaxs(ratio_com)

N_mcmc=1e4
N_estimate=1e4
N_repeat=100

p_estimate = matrix(0, nrow=length(q), ncol=N_repeat)
time.taken = NA
n_failure = NA #count the failure of MCMC sampling
set.seed(1)
for(k in 1:length(q))
{

  start.time = proc.time()
  
  avg = c(mu[k],mu[k])
  
  if(index[k]) #mu1 > mu2
  {
    sigma = diag(c(var1[k],var2[k]))
  }else
  {
    sigma = diag(c(var1[k],var2[k]))
  }
  
  #define the constraint
  a1 = c(0, 0)
  b1 = c(Inf, Inf)
  D1 = matrix(c(0, 1, 1, -q[k]), 2, 2)
  
  n_failure[k] = 0 #count the failure of MCMC sample
  for(i in 1:N_repeat)
  {
    #MCMC sample - gibbs sampling
    ISsample = rtmvnorm2(n=N_mcmc, mean=avg, sigma=sigma, lower=a1, upper=b1, D=D1, start.value=c(0,1), algorithm = 'gibbs', burn.in.samples=N_mcmc/10)
    
    ISsample = ISsample[!rowSums(!is.finite(ISsample)),]
    
    if(dim(ISsample)[1]==0) #if MCMC sampling often fails, skip the gene
    {
      n_failure[k] = n_failure[k]+1
      next;
    }
    
    #calculate cross-entropy optimal parameters
    mu_opt = colMeans(ISsample,na.rm=T)
    sigma_opt = var(ISsample)
    
    #estimating step
    y = mvtnorm::rmvnorm(n=N_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = mvtnorm::dmvnorm(x=y, mean=avg, sigma=sigma, log = T)
    log_lik1 = mvtnorm::dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    log_lik1 = dmnorm(x=y, mean = mu_opt, varcov=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    p_estimate[k,i] = sum(((y[,1]-q[k]*y[,2] >= 0)&(y[,2] >0))*lik_ratio)/N_estimate*2
  }
  
  time.taken[k] = (proc.time() - start.time)[3]
}

p_MCMC_CE = rowMeans(p_estimate)

p_res2 = replace(res1[,2], list=small_index, values = p_MCMC_CE)

res2_BH = p.adjust(p_res2, method = "BH")


#3.Crude permutation

#crude permutation
ind = 1:14
nperm = choose(14, 8)
perm1 = combinations(n=14, r=8, v=1:14)
perm2 = matrix(0, nrow=nperm, ncol=6)
for(i in 1:nperm)
{
  perm2[i,] = ind[(-perm1[i,])]
}

ngene = dim(exp)[1]
p_res = NA
p_res1 = NA
obs_ratio12 = rowMeans(exp[,1:n1]) / rowMeans(exp[,(1+n1):n])

for(i in 1:ngene)
{
  exp_temp = exp[i,]
  mu1 = rowMeans(matrix(exp_temp[t(perm1)], nrow=nperm, byrow=T))
  mu2 = rowMeans(matrix(exp_temp[t(perm2)], nrow=nperm, byrow=T))
  
  p_ratio = mu1/mu2

  #add 1 to the numerator and denominator
  p_res[i] = 2*min(sum(p_ratio >= obs_ratio12[i])/(nperm+1), sum(p_ratio <= obs_ratio12[i])/(nperm+1))
  
  #do not add 1
  p_res1[i] = 2*min(sum(p_ratio > obs_ratio12[i])/nperm, sum(p_ratio < obs_ratio12[i])/nperm)
}

res3_1_BH = p.adjust(p_res, method = "BH")
res3_2_BH = p.adjust(p_res1, method = "BH")

#######################################################################################################
#run the samr packages

label=c(rep(1,n1),rep(2,n2))

gname = rownames(mat)

samfit = SAM(x=exp, y=label, resp.type="Two class unpaired", genenames=gname,fdr.output=1,random.seed=100)

up_genes_sam = samfit$siggenes.table$genes.up
down_genes_sam = samfit$siggenes.table$genes.lo

res4 = rbind(up_genes_sam, down_genes_sam)

FDR_sam = as.numeric(as.character(res4[,7]))

#Table 4
Table4 = cbind(c(sum(res1_BH<0.001),sum(res2_BH<0.001),sum(res3_2_BH<0.001),sum(res3_1_BH<0.001),sum(FDR_sam<0.001*100)),
               c(sum(res1_BH<0.005),sum(res2_BH<0.005),sum(res3_2_BH<0.005),sum(res3_1_BH<0.005),sum(FDR_sam<0.005*100)),
               c(sum(res1_BH<0.01),sum(res2_BH<0.01),sum(res3_2_BH<0.01),sum(res3_1_BH<0.01),sum(FDR_sam<0.01*100)),
               c(sum(res1_BH<0.05),sum(res2_BH<0.05),sum(res3_2_BH<0.05),sum(res3_1_BH<0.05),sum(FDR_sam<0.05*100)),
               c(sum(res1_BH<0.1),sum(res2_BH<0.1),sum(res3_2_BH<0.1),sum(res3_1_BH<0.1),sum(FDR_sam<0.1*100)),
               c(sum(res1_BH<0.15),sum(res2_BH<0.15),sum(res3_2_BH<0.15),sum(res3_1_BH<0.15),sum(FDR_sam<0.15*100)))

#Table S8
#samr does not output those genes with FDR=1, output them
sam_res = merge(data.frame(GeneName = gname),data.frame(GeneName = res4[,1], samr.FDR = res4[,7]),by='GeneName',all.x=T)
sam_res$samr.FDR = as.numeric(as.character(sam_res$samr.FDR))
sam_res[is.na(sam_res$samr.FDR),'samr.FDR'] = 100

Table_S8 = merge_recurse(list(df1=data.frame(GeneName=gname, Ratio=res1[,'q'], BFMC.p=res1[,'p_value'], BFMC.FDR=res1_BH),
                          df2=data.frame(GeneName=gname, MCMC_CE.p=p_res2, MCMC_CE.FDR=res2_BH),
                          df3=data.frame(GeneName=gname, Perm0.p=p_res1, Perm0.FDR=res3_2_BH),
                          df4=data.frame(GeneName=gname, Perm1.p=p_res, Perm1.FDR=res3_1_BH),
                          df5=sam_res), by='GeneName')

write.table(Table_S8, file='/users/yangshi/projects/MCMC_CE/example3/TableS8.txt', row.names=F,quote=F, sep='\t')

save.image('/users/yangshi/projects/MCMC_CE/example3/example3.RData')