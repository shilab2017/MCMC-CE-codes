rm(list=ls())
library(matrixStats)
library(Hmisc)

load('D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\simulation.RData')

#calculate the average of the 100 repeatations
p_HMC_hat1 = rowMeans(p_HMC1)
p_HMC_hat2 = rowMeans(p_HMC2)
p_HMC_hat3 = rowMeans(p_HMC3)
p_HMC_hat4 = rowMeans(p_HMC4)

p_real = list(p_real1, p_real2, p_real3, p_real4)
p_HMC_hat = list(p_HMC_hat1,p_HMC_hat2,p_HMC_hat3,p_HMC_hat4)
p_HMC_matrix = list(p_HMC1,p_HMC2,p_HMC3,p_HMC4)
ARE = SMSE = list(p_real1, p_real2, p_real3, p_real4)

#calculate the relative error
for(i in 1:4)
{
  p_real_temp = p_real[[i]]
  p_HMC_temp = p_HMC_hat[[i]]
  
  ARE[[i]] = abs(p_HMC_temp - p_real_temp)/p_real_temp
  
  for(j in 1:length(p_real_temp))
  {
    SMSE[[i]][j] = cal_SMSE(p_HMC_matrix[[i]][j,],p_real_temp[j])
  }
}

res1 = data.frame(q=q1, p=p_real1, pD=p_d1, ARED=ARE_d1, pF=p_f1, AREF=ARE_f1, pI=p_i1, AREI=ARE_i1,
                  p_MC=p_HMC_hat1, ARE_MC=ARE[[1]], SMSE_MC=SMSE[[1]], Time=time.taken1)
res2 = data.frame(q=q2, p=p_real2, pD=p_d2, ARED=ARE_d2, pF=p_f2, AREF=ARE_f2, pI=p_i2, AREI=ARE_i2,
                  p_MC=p_HMC_hat2, ARE_MC=ARE[[2]], SMSE_MC=SMSE[[2]], Time=time.taken2)
res3 = data.frame(q=q3, p=p_real3, pD=p_d3, ARED=ARE_d3, pF=p_f3, AREF=ARE_f3, pI=p_i3, AREI=ARE_i3,
                  p_MC=p_HMC_hat3, ARE_MC=ARE[[3]], SMSE_MC=SMSE[[3]], Time=time.taken3)
res4 = data.frame(q=q4, p=p_real4, pD=p_d4, ARED=ARE_d4, pF=p_f4, AREF=ARE_f4, pI=p_i4, AREI=ARE_i4,
                  p_MC=p_HMC_hat4, ARE_MC=ARE[[4]], SMSE_MC=SMSE[[4]], Time=time.taken4)

#Make figure 1
png('D:\\GoogleDrive\\projects\\hamiltonianMC\\paper\\Figure1.png', width=20, height=20, units='in', res=300)
par(omi=c(0.5,0.5,0.5,0.5))                      #set the size of the outer margins
m = matrix(1:4, nrow=2,ncol=2, byrow = TRUE)
layout(mat = m, heights = c(0.5,0.5))
margin=c(4.5,4.5,2,2)
par(mar=margin)

plot(x=q1, y=log10(p_real1), type='l', lwd=3, xlim=c(25,500), ylim=c(-100,-5), xlab='q', ylab='log10(p-value)',
     font.lab=2, cex.lab=2.5, cex.axis=2)
points(x=q1, y=log10(p_HMC_hat1), cex=2, pch=19)
minor.tick()
text(x=450,y=-5,labels='m=5',font=2,cex=4)
mtext('A', side=2, font=2, cex=3,las=1,line=2,at=0)
#the error is very small, cannot be visually plotted:
#p1_upper = p_HMC_hat1+1.96*rowSds(p_HMC1)
#p1_lower = p_HMC_hat1-1.96*rowSds(p_HMC1)
#arrows(q1, log10(p1_lower), q1, log10(p1_upper), length=0.05, angle=90, code=3)

margin=c(4.5,4.5,2,2)
par(mar=margin)
plot(x=q2, y=log10(p_real2), type='l', lwd=3, xlim=c(50,550), ylim=c(-100,-5), xlab='q', ylab='log10(p-value)',
     font.lab=2, cex.lab=2.5, cex.axis=2)
points(x=q2, y=log10(p_HMC_hat2), cex=2, pch=19)
minor.tick()
text(x=500,y=-5,labels='m=20',font=2,cex=4)
mtext('B', side=2, font=2, cex=3,las=1,line=2,at=0)
#the error is very small, cannot be visually plotted:
#p2_upper = p_HMC_hat2+1.96*rowSds(p_HMC2)
#p2_lower = p_HMC_hat2-1.96*rowSds(p_HMC2)
#arrows(q2, log10(p2_lower), q2, log10(p2_upper), length=0.05, angle=90, code=3)

margin=c(4.5,4.5,2,2)
par(mar=margin)
plot(x=q3, y=log10(p_real3), type='l', lwd=3, xlim=c(100,650), ylim=c(-100,-5), xlab='q', ylab='log10(p-value)',
     font.lab=2, cex.lab=2.5, cex.axis=2)
points(x=q3, y=log10(p_HMC_hat3), cex=2, pch=19)
minor.tick()
text(x=600,y=-5,labels='m=50',font=2,cex=4)
mtext('C', side=2, font=2, cex=3,las=1,line=2,at=0)
#the error is very small, cannot be visually plotted:
#p3_upper = p_HMC_hat3+1.96*rowSds(p_HMC3)
#p3_lower = p_HMC_hat3-1.96*rowSds(p_HMC3)
#arrows(q3, log10(p3_lower), q3, log10(p3_upper), length=0.05, angle=90, code=3)

margin=c(4.5,4.5,2,2)
par(mar=margin)
plot(x=q4, y=log10(p_real4), type='l', lwd=3, xlim=c(150,750), ylim=c(-100,-5), xlab='q', ylab='log10(p-value)',
     font.lab=2, cex.lab=2.5, cex.axis=2)
points(x=q4, y=log10(p_HMC_hat4), cex=2, pch=19)
minor.tick()
text(x=700,y=-5,labels='m=100',font=2,cex=4)
mtext('D', side=2, font=2, cex=3,las=1,line=2,at=0)
#the error is very small, cannot be visually plotted:
#p4_upper = p_HMC_hat4+1.96*rowSds(p_HMC4)
#p4_lower = p_HMC_hat4-1.96*rowSds(p_HMC4)
#arrows(q4, log10(p4_lower), q4, log10(p4_upper), length=0.05, angle=90, code=3)

dev.off()

#write table S1-S4
write.table(res1, file='D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\table_s1.txt', row.names=F,
            quote=F, sep='\t')
write.table(res2, file='D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\table_s2.txt', row.names=F,
            quote=F, sep='\t')
write.table(res3, file='D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\table_s3.txt', row.names=F,
            quote=F, sep='\t')
write.table(res4, file='D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\table_s4.txt', row.names=F,
            quote=F, sep='\t')

save.image('D:\\GoogleDrive\\projects\\hamiltonianMC\\quadratic\\simulation_new.RData')