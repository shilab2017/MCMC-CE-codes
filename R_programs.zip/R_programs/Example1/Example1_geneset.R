rm(list=ls())

#load the packages used
library(TCGAbiolinks)
library(globaltest)
library(GSEABase)
library(KEGG.db)
library(GO.db)
library(org.Hs.eg.db)
library(CompQuadForm)
library(tmg)
library(quad)
library(matrixStats)
library(mvtnorm)
library(doParallel)
library(doRNG)
library(mygene)

#load the melanoma data - obtained from the TCGA data portal
load('/users/yangshi/projects/MCMC_CE/example1/melanoma.RData')

#load the script implementing Hamiltonian Monte Carlo - CE method for quadratic forms
source('/users/yangshi/projects/MCMC_CE/example1/MCMC_CE_quadratic.R')

gt.options(transpose = T)
go_gender_age = gtGO(clinical_dat$log2_breslow~as.factor(clinical_dat$gender)+clinical_dat$age1, exprs=expr, model='linear', annotation='org.Hs.eg.db',
                      multtest='BH')

go_res = go_gender_age@result

#select those GOs with p-value<1e-8 and have multiple genes
GO_use = rownames(go_res[go_res[,'p-value']<1e-8 & go_res[,'#Cov']>1,]) #35 GO terms

GO_gene_use = go_gender_age@subsets[GO_use]

#calculate residuals: y-mu_hat
fit1 = lm(log2_breslow~as.factor(gender)+age1, data=clinical_dat)

#get the residuals
clinical_dat$res = residuals(fit1)

Y = as.numeric(clinical_dat$res)
sigma_hat = sd(Y)

n_MCMC=1e4
n_estimate=1e4
n_burnin=1e3
n_repeat=100
ncore=8

p_MCMC_CE = matrix(0, nrow=length(GO_gene_use), ncol=n_repeat)
time.taken = NA
for(k in 1:length(GO_gene_use))
{
  X = as.matrix(expr[GO_gene_use[[k]],])

  A_mat = t(X)%*%X/length(Y)
  q = as.numeric(t(Y) %*% A_mat %*% Y)
  B_mat = A_mat * (sigma_hat^2)
  e_value = eigen(A_mat,only.values=T)$values
  cut_off = e_value[1]/1000
  e_value_used = e_value[e_value>=cut_off]

  lambda = e_value_used

  nu = length(lambda)

  D = diag(lambda)

  #Below are parameters for HMC-CE:
  sigma = diag(rep(1, nu)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
  mu = rep(0, nu) #mean of Y(multivariate normal), which is sqrt(delta)

  #alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
  M = solve(sigma)
  r = as.vector(M %*% mu)

  initial = rep(50, nu) #start value for the HMC sampler

  #quadratic constrains: (X^T)AX + (B^T)X + C >= 0
  A = D
  B = rep(0,nu)
  C = -q

  #the quadratic constraint of HMC for multivariate gaussian
  constr1 = list(A,B,C)

  cl = makeCluster(ncore)
  registerDoParallel(cl)

  start.time = proc.time()
  p_MCMC_CE[k,] = foreach(i=1:n_repeat, .packages=c('tmg','mvtnorm'),.combine=c) %dorng% 
  {  
    HMC_sample = rtmg(n=n_MCMC, M=M, r=r, initial=initial, q=list(constr1), burn.in=n_burnin)
  
    #estimate parameters of the optimal proposal density for importance sampling
    mu_opt = colMeans(HMC_sample)
    sigma_opt = var(HMC_sample)
  
    #estimating step
    y = rmvnorm(n=n_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(sum( (rowSums( (y * y) %*% D) >= q)*lik_ratio )/n_estimate)
  }
  
  stopCluster(cl)

  time.taken[k] = (proc.time() - start.time)[3]
}

#summarize the results
p_estimate = rowMeans(p_MCMC_CE)
sd_estimate = rowSds(p_MCMC_CE)

GO_term = names(GO_gene_use)
GO_alias = go_gender_age@extra
GO_description = GO_alias[match(GO_term,rownames(GO_alias)),2]

n_gene=entrez_id=gene_symbol=NA

for(i in 1:length(GO_gene_use))
{
  temp = GO_gene_use[[i]]
  n_gene[i] = length(temp)
  entrez_id[i] = paste(temp, collapse=', ')
  gene_symbol[i] = paste(queryMany(qterms=temp, scopes = 'entrezgene')$symbol, collapse = ', ')
}

result = data.frame(GO_term, n_gene, p_estimate, sd_estimate, GO_description, entrez_id, gene_symbol, time.taken)

result = result[order(result$p_estimate),]

write.table(result, file='/users/yangshi/projects/MCMC_CE/example1/melanoma_GO.txt', row.names=F,
            quote=F, sep='\t')

save.image('/users/yangshi/projects/MCMC_CE/example1/melanoma.RData')
