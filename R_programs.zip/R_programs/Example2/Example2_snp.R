rm(list=ls())

#load the libraries
library(matrixStats)
library(quad)
library(doParallel)
library(doRNG)
library(CompQuadForm)
library(tmg)
library(mvtnorm)

setwd('/users/yangshi/projects/MCMC_CE/example2')

#load the script implementing Hamiltonian Monte Carlo - CE method for quadratic forms
source('MCMC_CE_quadratic.R')

#load and pre-processing the data
#######################################################################################################
pheno = read.delim('CombinedPhenotypes.txt', header=T, stringsAsFactors=F)
geno = read.csv('mouse_hs1940.geno.txt',header=F, stringsAsFactors=F)
label = read.delim('mouse_hs1940.fam', header=F, stringsAsFactors=F)

#select response and covariates
subject.name = label[,2]
pheno_sub = pheno[pheno$SUBJECT.NAME %in% subject.name, c("SUBJECT.NAME","Biochem.HDL","sex","weight")]

pheno_com = pheno_sub[complete.cases(pheno_sub), ]

#re-format the genotype data
geno_new = geno[,4:1943]

row.names(geno_new) = gsub("-","_", geno[,1])

colnames(geno_new) = subject.name

geno_new1 = as.data.frame(t(geno_new))

geno_new1$SUBJECT.NAME = row.names(geno_new1)

final = merge(pheno_com, geno_new1, by='SUBJECT.NAME', all.x=T)

#check missing values
#any(is.na(final)) #no NA
#summary(final$Biochem.HDL)
#table(final$sex, useNA = 'always')
#summary(final$weight)

#remove three subjects with obscure sex
final1 = final[final$sex=='F'|final$sex=='M',]

#drop those SNPs that have only 1 genotypes among all subjects: their effects cannot be tested
var_snp = colVars(as.matrix(final1[,5:12230]))
index_rm = which(var_snp<1e-16)+4 #the column index of SNPs needs to be removed

final2 = final1[,-index_rm]
#######################################################################################################

#standardized the genotypes
snp_std = apply(final2[,5:10994], 2, FUN=scale)

final3 = data.frame(final2[,1:4], snp_std)

#simple linear regression for each SNP
SNP = colnames(final3)[5:10994]

#calculate p-values for each individual genes
p_value_single = NA
for(i in 1:length(SNP))
{
  formula = as.formula(paste0("Biochem.HDL~sex+weight+",SNP[i]))
  
  p_value_single[i] = summary(lm(formula, data=final3))$coefficients[4,'Pr(>|t|)']
  
}

#get the residuals
fit1 = lm(Biochem.HDL~sex+weight, data=final3)
final3$stdres = rstandard(fit1)

#group each adjacent 20 SNPs into one region
size.window = 20
num.window = floor(length(SNP)/size.window)
#p_value_region = stat_region = NA

#We first calculate the approximated p-values for all regions with approximations by pearson family distribution
Y = final3$stdres
data(mycoef)

cl = makeCluster(8)
registerDoParallel(cl)

res_region = foreach(i=1:num.window, .export='quadp', .combine=rbind) %dopar%
{
  X = snp_std[,((i-1)*size.window+1):(i*size.window)]
  fit = quadp(y=Y, A=X%*%t(X), mycoef)
  return(c(fit$stat,fit$p))
}

stopCluster(cl)

#summary(res_region[,2])

#head(sort(res_region[,2]))

#length(which(res_region[,2]<1e-8)) #70 regions with p-values<1e-8

#select those regions with p<1e-8
index_small_p = which(res_region[,2]<1e-8) #index of regions with p-values<1e-8

n_MCMC=1e4
n_estimate=1e4
n_burnin=1e3
n_repeat=100
ncore=8

p_MCMC_CE = matrix(0, nrow=length(index_small_p), ncol=n_repeat)
time.taken = NA
group_snp = NA

set.seed(1)

for(k in 1:length(index_small_p))
{
  ind = index_small_p[k]
  
  group_snp[k] = paste(SNP[((ind-1)*size.window+1):(ind*size.window)], collapse=', ')
  
  X = snp_std[,((ind-1)*size.window+1):(ind*size.window)]
  
  A = X%*%t(X)
  
  e_value = eigen(A, only.values=F)$values

  e_value_used = e_value[e_value>=e_value[1]/1000]
  
  q = as.numeric(t(Y) %*% A %*% Y)

#davies(q=q, lambda=e_value_used, lim=50000, acc=1e-100)

#farebrother(q=q, lambda=e_value_used, eps=1e-150)

#imhof(q=q, lambda=e_value_used)

  lambda = e_value_used

  nu = length(lambda)

  D = diag(lambda)

  #Below are parameters for HMC-CE:
  sigma = diag(rep(1, nu)) #covariance matrix of Y(multivariate normal), which is diagonal matrix of 1's
  mu = rep(0, nu) #mean of Y(multivariate normal), which is sqrt(delta)
  n_HMC = 1e4 #number of HMC samples

  #alternative parameterization of multivariate normal in Hamiltonian Monte Carlo method
  M = solve(sigma)
  r = as.vector(M %*% mu)

  initial = rep(50, nu) #start value for the HMC sampler

  #quadratic constrains: (X^T)AX + (B^T)X + C >= 0
  A = D
  B = rep(0,nu)
  C = -q

#t(initial) %*% A %*% initial + t(B) %*% initial + C

  #the quadratic constraint of HMC for multivariate gaussian
  constr1 = list(A,B,C)

  cl = makeCluster(ncore)
  registerDoParallel(cl)
  
  start.time = proc.time()
  
  p_MCMC_CE[k,] = foreach(i=1:n_repeat, .packages=c('tmg','mvtnorm'),.combine=c) %dorng% 
  {  
    HMC_sample = rtmg(n=n_MCMC, M=M, r=r, initial=initial, q=list(constr1), burn.in=n_burnin)
    
    #estimate parameters of the optimal proposal density for importance sampling
    mu_opt = colMeans(HMC_sample)
    sigma_opt = var(HMC_sample)
    
    #estimating step
    y = rmvnorm(n=n_estimate, mean=mu_opt, sigma=sigma_opt)
    log_lik0 = dmvnorm(x=y, mean=mu, sigma=sigma, log = T)
    log_lik1 = dmvnorm(x=y, mean=mu_opt, sigma=sigma_opt, log = T)
    lik_ratio = exp(log_lik0 - log_lik1)
    return(sum( (rowSums( (y * y) %*% D) >= q)*lik_ratio )/n_estimate)
  }
  
  stopCluster(cl)
  
  time.taken[k] = (proc.time() - start.time)[3]
}

#summarize results
p_estimate = rowMeans(p_MCMC_CE)
sd_estimate = rowSds(p_MCMC_CE)

Group_index = paste("Group",index_small_p)

res = data.frame(Group_index, p_estimate, sd_estimate, time.taken, group_snp)
res = res[order(res$p_estimate),]

write.table(res, file='/users/yangshi/projects/MCMC_CE/example2/snp.txt', row.names=F,
            quote=F, sep='\t')

save.image('/users/yangshi/projects/MCMC_CE/example2/snp.RData')